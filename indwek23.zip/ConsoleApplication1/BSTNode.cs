﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IndustrialProgramming
{
    class BSTNode<T> where T : IComparable
    {

        private T value;
        private BSTNode<T> leftNode;
        private BSTNode<T> rightNode;

        public BSTNode(T value)
        {
            this.value = value;
        }

        public T GetValue()
        {
            return value;
        }

        public BSTNode<T> GetLeftChild()
        {
            return leftNode;
        }

        public BSTNode<T> GetRightChild()
        {
            return rightNode;
        }

        public void SetLeftChild(BSTNode<T> newNode)
        {
            this.leftNode = newNode;
        }

        public void SetRightChild(BSTNode<T> newNode)
        {
            this.rightNode = newNode;
        }

    }
}
