﻿using System;
using System.Collections.Generic;

namespace IndustrialProgramming {
    class Program {

        enum Weekday { Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday };
        enum Days { WorkDay, Weekend };

        struct ComplexNumber {
            public double real, imaginary;

            public ComplexNumber(double real, double imaginary) {
                this.real = real;
                this.imaginary = imaginary;
            }

            // Returns a nicely formatted string representation of the complex number
            public String StringRep() {
                return (imaginary < 0) ? real + " - " + Math.Abs(imaginary) + "i" : real + " + " + imaginary + "i";
            }

        }

        static void Main(string[] args) {
            Program program = new Program();
            if (args.Length < 0) {
                Console.WriteLine("Argument required: [gcd/mm/bst]");
                return;
            }

            switch (args[0]) {
                case "gcd":
                    if (args.Length < 3) {
                        Console.WriteLine("Usage: gcd [arg 1] [arg 2]");
                    } else {
                        Console.WriteLine("Greatest Common Divisor of " + args[1] + " and " + args[2] + " is: " + Gcd(int.Parse(args[1]), int.Parse(args[2])));
                    }
                    break;
                case "mm":
                    int[,] x = { { 3, 4, 5 }, { 2, 3, 6 } };
                    int[,] y = { { 1, 2 }, { 6, 7 }, { 5, 3 } };
                    int[,] result = multiplyMatrices(x, y);
                    Console.WriteLine("Result of ");
                    program.printMatrix(x);
                    Console.WriteLine("*");
                    program.printMatrix(y);
                    Console.WriteLine("=");
                    program.printMatrix(result);
                    break;
                case "bst":
                    BST<double> bst = new BST<double>(double.Parse(args[1]));
                    Console.WriteLine("BST created with root value {0} and type double\n", args[1]);

                    Console.WriteLine("Inserting 30.12");
                    bst.Insert(30.12);
                    Console.WriteLine("Inserting 20.0");
                    bst.Insert(20.0);
                    Console.WriteLine("Inserting 40.34");
                    bst.Insert(40.34);
                    Console.WriteLine("Inserting 70");
                    bst.Insert(70);
                    Console.WriteLine("Inserting 60.98");
                    bst.Insert(60.98);
                    Console.WriteLine("Inserting 80\n");
                    bst.Insert(80);

                    Console.WriteLine("In-order traversal of BST:");
                    bst.inorderTraversal();
                    Console.WriteLine("Traversal end\n");

                    for (int i = 20; i < 91; i += 10) {
                        Console.WriteLine("Find({0}): {1}", i, bst.Find(i));
                    }

                    Console.WriteLine("Find(-12): {0}", bst.Find(-12));
                    Console.WriteLine("Find(1000): {0}\n", bst.Find(1000));

                    BST<char> charBST = new BST<char>(char.Parse(args[2]));
                    Console.WriteLine("BST created with root value {0} and type char", args[2]);
                    Console.WriteLine("Inserting a");
                    charBST.Insert('a');
                    Console.WriteLine("Inserting c");
                    charBST.Insert('c');
                    Console.WriteLine("Inserting z");
                    charBST.Insert('z');
                    Console.WriteLine("Inserting m");
                    charBST.Insert('m');
                    Console.WriteLine("Inserting k");
                    charBST.Insert('k');
                    Console.WriteLine("Inserting e\n");
                    charBST.Insert('e');

                    Console.WriteLine("In-order traversal of BST:");
                    charBST.inorderTraversal();
                    Console.WriteLine("Traversal end\n");

                    Console.WriteLine("Find(a): {0}", charBST.Find('a'));
                    Console.WriteLine("Find(c): {0}", charBST.Find('c'));
                    Console.WriteLine("Find(z): {0}", charBST.Find('z'));
                    Console.WriteLine("Find(m): {0}", charBST.Find('m'));
                    Console.WriteLine("Find(k): {0}", charBST.Find('k'));
                    Console.WriteLine("Find(e): {0}", charBST.Find('e'));


                    Console.WriteLine("Find(q): {0}", charBST.Find('q'));
                    Console.WriteLine("Find(r): {0}", charBST.Find('r'));

                    break;
                case "setstep":
                    int[] testArr = { 1, 2, 3, 4, 5 };
                    Console.WriteLine("Array as initialized:");
                    foreach (int i in testArr) {
                        Console.Write("{0} ", i);
                    }
                    program.Set0(testArr);
                    Console.WriteLine("\nArray with elements set to 0:");
                    foreach (int i in testArr) {
                        Console.Write("{0} ", i);
                    }
                    ComplexNumber test = new ComplexNumber(3, -5);
                    Console.WriteLine("\n{0}", test.StringRep());
                    break;
                case "complexdiv":
                    Console.WriteLine(program.DivComplex(new ComplexNumber(3, 4), new ComplexNumber(1, 2)).StringRep());
                    break;
                case "readline":
                    int[] res = program.CountOccurences();

                    Console.WriteLine("ushorts: {0} | uints: {1} | ulongs: {2}", res[0], res[1], res[2]);
                    break;
            }

        }

        // Deﬁne weekday as an enumeration type and implement a nextday method
        private Weekday NextDay(Weekday day) {
            // Returns next day, looping to Monday(0) when given Sunday(7)
            return (Weekday)((int)(day + 1) % 7);
        }

        // Implement a whatday method returning either workday or weekend (use another enum)
        private Days WhatDay(Weekday day) {
            switch (day) {
                case Weekday.Monday:
                case Weekday.Tuesday:
                case Weekday.Wednesday:
                case Weekday.Thursday:
                case Weekday.Friday:
                    return Days.WorkDay;
                default:
                    return Days.Weekend;
            }
        }


        // Write a method calculating the sum from 1 to n, for a ﬁxed integer value n
        private int sum(int n) {
            int sum = 0;
            for (int i = 1; i <= n; i++) {
                sum += i;
            }
            return sum;
        }

        // Write a method calculating the sum over an array (one version with foreach, one version with explicit indexing)
        private int SumOverArray(int[] arr, bool useForEach) {
            int sum = 0;
            if (useForEach) {
                foreach (int i in arr) {
                    sum += i;
                }
            } else {
                for (int i = 0; i < arr.Length; i++) {
                    sum += arr[i];
                }
            }
            return sum;
        }
        // Use the setstep method to implement a method set0, which sets all array elements to the value 0.
        // author of SetStep(): Hans Wolfgang-Loidl
        static void SetStep(int[] arr, ref int n, int x) {
            arr[n] = x;
            n += 1;
        }

        private void Set0(int[] arr) {
            int n = 0;
            while (n < arr.Length) {
                SetStep(arr, ref n, 0);
            }
        }

        // Deﬁne complex numbers using structs, and implement basic arithmetic on them.
        private ComplexNumber AddComplex(ComplexNumber a, ComplexNumber b) {
            double real = a.real + b.real;
            double imaginary = a.imaginary + b.imaginary;
            return new ComplexNumber(real, imaginary);
        }

        private ComplexNumber MultComplex(ComplexNumber a, ComplexNumber b) {
            double real = (a.real * b.real) - (a.imaginary * b.imaginary);
            double imaginary = (a.real * b.imaginary) + (a.imaginary * b.real);
            return new ComplexNumber(real, imaginary);
        }

        private ComplexNumber SubComplex(ComplexNumber a, ComplexNumber b) {
            double real = a.real - b.real;
            double imaginary = a.imaginary - b.imaginary;
            return new ComplexNumber(real, imaginary);
        }

        // Returns null as unimplemented
        private ComplexNumber DivComplex(ComplexNumber a, ComplexNumber b) {
            return new ComplexNumber((((a.real * b.real) + (a.imaginary * b.imaginary)) / ((b.real * b.real) + (b.imaginary * b.imaginary))), (((a.imaginary * b.real) - (a.real * b.imaginary)) / ((b.real * b.real) + (b.imaginary * b.imaginary))));
        }

        private int[] CountOccurences() {
            List<string> inputs = new List<string>();
            do {
                inputs.Add(Console.ReadLine());

            } while (!(inputs.Contains("end")));
            int[] results = new int[3];
            inputs.Remove("end");
            foreach (String s in inputs) {
                if (ulong.Parse(s) < ushort.MaxValue) {
                    results[0]++;
                } else if (ulong.Parse(s) < ulong.MinValue) {
                    results[1]++;
                } else {
                    results[2]++;
                }

            }
            return results;
        }

        // Implement matrix multiplication as a static method taking two 2-dimensional arrays (of any size) as arguments.
        private static int[,] multiplyMatrices(int[,] x, int[,] y) {
            if (!(x.GetLength(1) == y.GetLength(0))) {
                Console.WriteLine("Number of columns in first matrix must equal number of rows in second matrix");
                return null;
            }

            int[,] result = new int[x.GetLength(0), y.GetLength(1)];

            for (int i = 0; i < result.GetLength(0); i++) {
                for (int j = 0; j < result.GetLength(1); j++) {
                    result[i, j] = 0;
                    for (int k = 0; k < x.GetLength(1); k++) {
                        result[i, j] += x[i, k] * y[k, j];
                    }
                }
            }

            return result;
        }
        // Print Matrix function for testing matrix multiplication
        private void printMatrix(int[,] matrix) {
            for (int i = 0; i < matrix.GetLength(0); i++) {
                for (int j = 0; j < matrix.GetLength(1); j++) {
                    if (j == matrix.GetLength(1) - 1) {
                        Console.Write(matrix[i, j] + "\n");
                    } else {
                        Console.Write(matrix[i, j] + ",");
                    }
                }
            }
        }

        // Implement Euclid’s greatest common divisor algorithm as a static method over two int parameters.
        private static int Gcd(int x, int y) {
            int remainder;

            if (x < y) {
                int temp = x;
                x = y;
                y = temp;
            }
            while (true) {
                remainder = x % y;
                if (remainder != 0) {
                    x = y;
                    y = remainder;
                    continue;
                } else {
                    return y;
                }
            }
        }

    }


}
