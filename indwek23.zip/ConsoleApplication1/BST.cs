﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IndustrialProgramming
{
    class BST<T> where T : IComparable
    {
        /**
         * This BST can be used with any type that implements IComparable interface.
         * This is:
         * int
         * double
         * char
         * float
         * DateTime
         */

        private BSTNode<T> root;

        public BST(T rootValue)
        {
            root = new BSTNode<T>(rootValue);
        }

        public void Insert(T value)
        {
            InsertionHelper(root, value);
        }

        // The purpose of the helper function is so that I do not need to pass the BST root node to the Insert function
        private BSTNode<T> InsertionHelper(BSTNode<T> root, T value)
        {
            // In this context the value of "root" is determined by the argument and not the class field "root"

            // If root is null create a new node and return it
            if (root == null)
            {
                root = new BSTNode<T>(value);
                return root;
            }

            // Otherwise recurse through the tree until we find the correct location to place the value
            if (value.CompareTo(root.GetValue()) < 0)
            {
                root.SetLeftChild(InsertionHelper(root.GetLeftChild(), value));
            }
            else if (value.CompareTo(root.GetValue()) > 0)
            {
                root.SetRightChild(InsertionHelper(root.GetRightChild(), value));
            }

            return root;
        }

        public bool Find(T value)
        {
            return (FindHelper(root, value) != null) ? true : false;
        }

        // The purpose of the helper functions is so that I do not need to pass the BST root node to the Find function
        private BSTNode<T> FindHelper(BSTNode<T> root, T value)
        {
            if (root == null) return root;
            if (root.GetValue().CompareTo(value) == 0) return root;
            if (root.GetValue().CompareTo(value) > 0) return FindHelper(root.GetLeftChild(), value);
            return FindHelper(root.GetRightChild(), value);
        }

        public void inorderTraversal()
        {
            inorderTraversalHelper(root);
        }

        private void inorderTraversalHelper(BSTNode<T> root)
        {
            if (root != null)
            {
                inorderTraversalHelper(root.GetLeftChild());
                Console.WriteLine(root.GetValue());
                inorderTraversalHelper(root.GetRightChild());
            }
        }

        public BSTNode<T> getRoot()
        {
            return root;
        }

    }
}
